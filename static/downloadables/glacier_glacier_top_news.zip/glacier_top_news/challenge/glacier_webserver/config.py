from flask import Flask

app = Flask(__name__)

# app.config['EXPLAIN_TEMPLATE_LOADING'] = True
